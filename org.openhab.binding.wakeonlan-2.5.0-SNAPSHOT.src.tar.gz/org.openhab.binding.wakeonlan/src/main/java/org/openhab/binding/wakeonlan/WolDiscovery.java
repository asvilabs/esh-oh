/**
 * Copyright (c) 2010-2018 by the respective copyright holders.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * @author Ganesh Ingle <ganesh.ingle@asvilabs.com>
 */
package org.openhab.binding.wakeonlan;

import static org.openhab.binding.wakeonlan.WakeOnLanBindingConstants.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.smarthome.config.discovery.AbstractDiscoveryService;
import org.eclipse.smarthome.config.discovery.DiscoveryResult;
import org.eclipse.smarthome.config.discovery.DiscoveryResultBuilder;
import org.eclipse.smarthome.config.discovery.DiscoveryService;
import org.eclipse.smarthome.config.discovery.inbox.Inbox;
import org.eclipse.smarthome.config.discovery.inbox.InboxPredicates;
import org.eclipse.smarthome.core.thing.Thing;
import org.eclipse.smarthome.core.thing.ThingRegistry;
import org.eclipse.smarthome.core.thing.ThingUID;
import org.openhab.binding.wakeonlan.internal.ExecUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a {@link DiscoveryService} implementation, which can find IPv4 devices in the network
 * using an external shell script.<br/>
 * The script uses Linux tools like ip, host, ping, avahi-resolve, nmblookup
 * to find out hostnames, their MAC addresses and outgoing network adapters.
 *
 * @author Ganesh Ingle - Initial contribution
 *
 */
// @Component(immediate = true, service = DiscoveryService.class, configurationPid = "discovery.wakeonlan")
public class WolDiscovery extends AbstractDiscoveryService {

    private static Logger logger = LoggerFactory.getLogger(BINDING_LOGGER_NAME);
    private long lastScan = 0l;
    // BundleContext bundleContext = null;
    protected int limit;
    protected int timeoutSec;
    protected int ttlSec;

    // @Reference(policy = ReferencePolicy.DYNAMIC)
    protected volatile Inbox inbox;
    // @Reference(policy = ReferencePolicy.DYNAMIC)
    protected volatile ThingRegistry thingRegistry;

    void initDefaults() {
        limit = DFLT_DISCOVERY_RESULTS_LIMIT;
        timeoutSec = DFLT_DISCOVERY_TIMEOUT_SEC;
        ttlSec = DFLT_DISCOVERY_RESULT_TTL_SEC;
    }

    public WolDiscovery() {
        super(SUPPORTED_THING_TYPES_UIDS, DFLT_DISCOVERY_TIMEOUT_SEC + 1, false);
    }

    @Override
    protected void activate(Map<String, Object> configProperties) {
        logger.info("Wake on LAN Discovery Service starting");
        scanLock = 0;
        initDefaults();
        loadProps(configProperties);
        super.activate(configProperties);
    }

    @Override
    protected void modified(Map<String, Object> configProperties) {
        loadProps(configProperties);
        super.modified(configProperties);
    }

    protected void loadProps(Map<String, Object> configProperties) {
        if (configProperties != null) {
            Object propObj = configProperties.get(DISCOVERY_CONFIG_RESULTS_LIMIT);
            if (propObj != null) {
                try {
                    limit = Integer.parseInt(String.valueOf(propObj));
                } catch (NumberFormatException e) {
                    logger.warn("INVALID config property value {}={}", DISCOVERY_CONFIG_RESULTS_LIMIT, propObj);
                }
            }
            propObj = configProperties.get(DISCOVERY_CONFIG_DISCOVERY_TIMEOUT_SEC);
            if (propObj != null) {
                try {
                    timeoutSec = Integer.parseInt(String.valueOf(propObj));
                } catch (NumberFormatException e) {
                    logger.warn("INVALID config property value {}={}", DISCOVERY_CONFIG_DISCOVERY_TIMEOUT_SEC, propObj);
                }
            }
            propObj = configProperties.get(DISCOVERY_CONFIG_RESULTS_TTL_SEC);
            if (propObj != null) {
                try {
                    ttlSec = Integer.parseInt(String.valueOf(propObj));
                } catch (NumberFormatException e) {
                    logger.warn("INVALID config property value {}={}", DISCOVERY_CONFIG_RESULTS_TTL_SEC, propObj);
                }
            }
        }
    }

    protected boolean hasSeenSameThingUIDBefore(@NonNull ThingUID thingUid) {
        if (thingRegistry != null && thingRegistry.get(thingUid) != null) {
            return true;
        } else if (inbox != null) {
            long hostExistsAlready = inbox.stream().filter(InboxPredicates.forThingUID(thingUid)).count();
            if (hostExistsAlready > 0) {
                return true;
            }
        }
        return false;
    }

    protected boolean hasSeenSameMacBeforeOnSameNetworkOrHost(@NonNull String mac, @NonNull String targetBroadcastIP,
            @NonNull String pingHostnameOrIp) {
        if (thingRegistry != null) {
            Collection<@NonNull Thing> things = thingRegistry.getAll();
            for (Thing thing : things) {
                if (!thing.getThingTypeUID().equals(THING_TYPE_WOLDEVICE)) {
                    continue;
                }
                WakeOnLanConfiguration config = thing.getConfiguration().as(WakeOnLanConfiguration.class);
                if (mac.equals(String.valueOf(config.targetMAC).toLowerCase().replaceAll("[_:-]", ""))
                        && (targetBroadcastIP.equals(config.targetIP)
                                || pingHostnameOrIp.equalsIgnoreCase(config.pingHostnameOrIp))) {
                    return true;
                }
            }
        }
        if (inbox != null) {
            Iterator<@NonNull DiscoveryResult> results = inbox.stream()
                    .filter(InboxPredicates.forThingTypeUID(THING_TYPE_WOLDEVICE)).iterator();
            if (results != null) {
                while (results.hasNext()) {
                    DiscoveryResult d = results.next();
                    String targetMac = String.valueOf(d.getProperties().get(THING_CONFIG_TARGET_MAC));
                    if (targetMac != null && targetMac.toLowerCase().replaceAll("[_:-]", "").equals(mac)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    protected void deactivate() {
        scanLock = 0;
        super.deactivate();
    }

    Integer scanLock = 0;

    @Override
    protected void startScan() {
        logger.debug("startScan()");
        String operatingSystem = System.getProperty("os.name", "Unknown");
        if (operatingSystem.toLowerCase().indexOf("linux") == -1) {
            logger.debug("skipping scan, OS {} not supported yet", operatingSystem);
            return;
        }
        synchronized (scanLock) {
            if (scanLock == 1) {
                logger.warn("skipping scan, one scan already in progress");
                return;
            } else {
                scanLock = 1;
            }
        }

        try {
            if ((System.currentTimeMillis() - lastScan) < timeoutSec * 1000) {
                logger.warn("skipping scan, called too soon. Try again after couple of minutes");
                return;
            }
            lastScan = System.currentTimeMillis();
            File tmpScript = new File(System.getProperty("java.io.tmpdir") + "/wol-discovery.sh");
            if (tmpScript.exists()) {
                tmpScript.delete();
                tmpScript.createNewFile();
            }
            tmpScript.deleteOnExit();
            URL scriptUrl = this.getClass().getClassLoader().getResource("scripts/wol-discovery.sh");
            if (scriptUrl == null) {
                scriptUrl = this.getClass().getClassLoader().getResource("/scripts/wol-discovery.sh");
            }
            if (scriptUrl == null) {
                scriptUrl = this.getClass().getClassLoader().getResource("wol-discovery.sh");
            }
            if (scriptUrl == null) {
                logger.warn("Wake on LAN Discovery failed. wol-discovery.sh not found in Bundle");
                return;
            }
            BufferedInputStream is = new BufferedInputStream(scriptUrl.openStream());
            BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(tmpScript));
            while (is.available() > 0) {
                byte[] b = new byte[1024];
                int bytes = is.read(b);
                if (bytes > 0) {
                    os.write(b, 0, bytes);
                }
            }
            is.close();
            os.flush();
            os.close();

            Map<Integer, String> r = ExecUtil.executeCommandLineAndWaitResponse(
                    "/bin/bash" + ExecUtil.DELIMITER + tmpScript.getAbsolutePath() + ExecUtil.DELIMITER + limit,
                    timeoutSec * 1000, logger);
            tmpScript.delete();
            if (r.size() == 0 || r.keySet().iterator().next() != 0) {
                logger.warn("Wake on LAN Discovery failed. ");
                return;
            }
            String scriptOutput = r.values().iterator().next();
            if (scriptOutput != null && scriptOutput.trim().length() > 0) {
                String[] lines = scriptOutput.split("\n");
                for (String line : lines) {
                    String[] fields = line.split("[ \t]+");
                    if (fields.length >= 3) {
                        String hostname = fields[0];
                        String macWithSeparators = fields[1];
                        String dev = fields[2];
                        String broad = "255.255.255.255";
                        boolean broadCastIPDiscovered = false;
                        if (fields.length > 3) {
                            broad = fields[3];
                            broadCastIPDiscovered = true;
                        }
                        String hostnameWithoutLocal = hostname.replaceAll("[.]local$", "");
                        String mac = macWithSeparators.replaceAll("[:_-]", "");

                        // don't include mac in thing uid and label if it is first network card
                        // This makes UI look cleaner
                        String uid = hostnameWithoutLocal.replaceAll("[^A-Za-z0-9_-]", "-");
                        String label = "Wol (" + hostnameWithoutLocal + ")";
                        ThingUID thingUid = new ThingUID(THING_TYPE_WOLDEVICE, uid);

                        // include mac in thing uid if it is additional network card
                        String uidMultihomedHost = uid + "_" + mac;

                        // include broadcast IP in label if it is additional network card
                        // not including mac because its less human friendly than subnet broadcast IP
                        String labelMultihomedHost = "Wol (" + hostnameWithoutLocal + " ; " + broad + ")";

                        // sometimes people have to clone macs across devices, e.g mac registerd with ISP's RADIUS
                        // server may need to be cloned to different router when you change network hardware around
                        // we do allow same mac on two Things as long as they appear on different subnets and different
                        // host.
                        if (hasSeenSameMacBeforeOnSameNetworkOrHost(mac, broad, hostname)) {
                            continue;
                        }

                        if (hasSeenSameThingUIDBefore(thingUid)) {
                            // Same hostname, additional newtwork card
                            label = labelMultihomedHost;
                            uid = uidMultihomedHost;
                        }
                        logger.info("Found WOL device: {}", line);
                        Map<String, Object> props = new HashMap<>();
                        props.put(THING_CONFIG_TARGET_MAC, mac);
                        props.put(THING_CONFIG_TARGET_IP, broad);

                        // interfaceHint Thing property is useful to ping feature when hostname resolves to
                        // link-local IP such as 169.254.231.234 instead of
                        // global scoped IP such as 10.0.1.1 and link-local IP is not present
                        // in routing table. Ping fails to select outgoing card. Hence we use
                        // this hint to tell ping to use specific card
                        props.put(THING_PROP_IF_HINT, dev);

                        if (!broadCastIPDiscovered) {
                            // broadcast IP is set to 255.255.255.255, limited broadcast
                            // send it on specific network card
                            props.put(THING_CONFIG_SEND_ON_IF, dev);
                        }
                        // else {
                        // broadcast IP is set to directed broadcast e.g 192.168.1.255
                        // subnet broadcast IP will be used by kernel to
                        // auto-select outgoing nw card based on routing table.
                        // so lets keep interface name as hint only
                        // }
                        props.put(THING_CONFIG_SET_SO_BROAD, true);
                        props.put(THING_CONFIG_PERIODIC_PING, true);
                        props.put(THING_CONFIG_SEND_ON_ALL_IF, false);
                        props.put(THING_CONFIG_PING_HOST, hostname);
                        props.put(THING_CONFIG_TARGET_MAC, mac);
                        props.put(THING_PROP_REPRESENTATION, uidMultihomedHost);
                        DiscoveryResult wolDevice = DiscoveryResultBuilder
                                .create(new ThingUID(THING_TYPE_WOLDEVICE, uid)).withLabel(label).withProperties(props)
                                .withRepresentationProperty(THING_PROP_REPRESENTATION).withTTL(ttlSec).build();
                        thingDiscovered(wolDevice);
                    }
                }
            }
        } catch (IOException e) {
            logger.warn("Wake on LAN Discovery failed. ", e);
        } catch (InterruptedException e) {
            return;
        } finally {
            scanLock = 0;
        }
    }
}
