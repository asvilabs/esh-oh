/**
 * Copyright (c) 2010-2018 by the respective copyright holders.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * @author Ganesh Ingle <ganesh.ingle@asvilabs.com>
 */

package org.openhab.binding.wakeonlan.internal;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.exec.ExecuteException;
import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;
import org.slf4j.Logger;

/**
 * Handles built-in Java ping or external command ping
 *
 * @author Ganesh Ingle - Initial contribution
 *
 */
public class PingHelper {
    protected static String pingLocation = null;
    public static final Integer TIMEOUT_SEC = 10;
    public static final Integer TIMEOUT_MILLIS = TIMEOUT_SEC * 1000;
    public static final Integer TTL = 10; // hop count
    static {
        detectPingBinaryLocation();
    }

    private static synchronized void detectPingBinaryLocation() {
        String osname = System.getProperty("os.name");
        if (osname.indexOf("win") >= 0) {
            pingLocation = "ping";
        } else {
            for (String loc : new String[] { "/bin", "/usr/sbin", "/sbin", "/usr/bin", "/usr/local/bin",
                    "/usr/local/sbin" }) {
                File f = new File(loc + "/ping");
                if (f.canExecute()) {
                    pingLocation = loc + "/ping";
                }
            }
            if (pingLocation == null) {
                pingLocation = "ping";
            }
        }
    }

    protected static String getPingCommandByOS(@NonNull String hostnameOrIp, @Nullable String iface)
            throws UnsupportedOSException {
        // Supported OSes: Linux, Solaris, Unix, Mac, Windows
        String osname = System.getProperty("os.name");
        if (osname == null || osname.length() == 0) {
            throw new UnsupportedOSException("Couldn't determine os name. Checked System.getProperty(\"os.name\")");
        }
        osname = osname.toLowerCase();
        String sep = ExecUtil.DELIMITER;
        String ping = pingLocation;
        if (osname.indexOf("linux") >= 0 || osname.indexOf("mac") >= 0) {
            // manpage: https://linux.die.net/man/8/ping
            // manpage: https://www.unix.com/man-page/osx/8/ping/
            if (iface != null) {
                return ping + sep + "-c" + "3" + sep + "-I" + iface + sep + "-W" + TIMEOUT_SEC + sep + "-t" + TTL + sep
                        + hostnameOrIp;
            } else {
                return ping + sep + "-c" + "3" + sep + "-W" + TIMEOUT_SEC + sep + "-t" + TTL + sep + hostnameOrIp;
            }
        } else if (osname.indexOf("win") > 0) {
            // Not sure '-S source address' option supports interface name as well
            // manpage: https://www.lifewire.com/ping-command-2618099
            return ping + sep + "-n" + sep + "3" + sep + "-i" + sep + TTL + sep + "-w" + sep + TIMEOUT_MILLIS + sep
                    + hostnameOrIp;
        } else if (osname.matches(".*free.*bsd.*")) {
            // Not sure '-S source address' option supports interface name as well
            // manpage: https://www.freebsd.org/cgi/man.cgi?query=ping&sektion=8&apropos=0&manpath=FreeBSD+4.3-RELEASE
            return ping + sep + "-c" + sep + "3" + sep + "-t" + sep + TIMEOUT_SEC + sep + "-T" + sep + TTL + sep
                    + hostnameOrIp;
        } else if (osname.matches(".*open.*bsd.*")) {
            // manpage: https://man.openbsd.org/ping.8
            return ping + sep + "-c" + sep + "3" + sep + "-w" + sep + TIMEOUT_SEC + sep + hostnameOrIp;
        } else if (osname.matches(".*hp.*ux.*")) {
            // manpage: http://nixdoc.net/man-pages/hp-ux/man1/ping.1m.html
            return ping + sep + hostnameOrIp + sep + "-n" + sep + "3" + sep + "-m" + sep + TIMEOUT_SEC;
        } else if (osname.indexOf("sunos") > 0 || osname.indexOf("sun os") > 0 || osname.indexOf("solaris") > 0) {
            // manpage: https://docs.oracle.com/cd/E26505_01/html/816-5166/ping-1m.html
            if (iface != null) {
                return ping + sep + "-i" + sep + iface + sep + hostnameOrIp + sep + TIMEOUT_SEC;
            } else {
                return ping + sep + "-t" + sep + TTL + sep + hostnameOrIp + sep + TIMEOUT_SEC;
            }
        } else {
            throw new UnsupportedOSException(
                    "OS " + osname + " not supported. Don't know ping command syntax and location");
        }
    }

    public static boolean isHostOnlineExternalPing(String hostnameOrIp, @Nullable String ifaceStrict,
            @Nullable String ifaceHint, @Nullable Logger logger)
            throws UnsupportedOSException, ExecuteException, InterruptedException, IOException {
        Set<String> tryCommands = new LinkedHashSet<>();
        if (ifaceStrict != null) {
            tryCommands.add(getPingCommandByOS(hostnameOrIp, ifaceStrict));
        }
        if (ifaceHint != null) {
            tryCommands.add(getPingCommandByOS(hostnameOrIp, ifaceHint));
        }
        tryCommands.add(getPingCommandByOS(hostnameOrIp, null));
        if (logger != null) {
            logger.debug("External ping: {}", hostnameOrIp);
        }
        for (String cmdLine : tryCommands) {
            Map<Integer, String> ret = ExecUtil.executeCommandLineAndWaitResponse(cmdLine, TIMEOUT_MILLIS + 1000,
                    logger);
            if (ret.size() == 0) {
                String cmdWithSpaces = cmdLine.replaceAll("@@", " ");
                if (logger != null) {
                    logger.warn("Ping command failed: {}", cmdWithSpaces);
                }
            } else if (ret.keySet().iterator().next() != 0) {
                // ping returns non-zero when host is unreachable
            } else {
                if (logger != null) {
                    logger.debug("Host {} seems to be online.", hostnameOrIp);
                }
                return true;
            }
        }
        if (logger != null) {
            logger.debug("Host {} seems to be down.", hostnameOrIp);
        }
        return false;
    }

    protected static @Nullable NetworkInterface getIface(@NonNull String ifaceName, @Nullable Logger logger) {
        NetworkInterface iface = null;
        try {
            iface = NetworkInterface.getByName(ifaceName);
        } catch (SocketException | NullPointerException e) {
            if (logger != null) {
                logger.warn("Unable to get nw interface. ", e);
            }
        }
        return iface;
    }

    public static boolean isHostOnlineJava(@NonNull String hostnameOrIp, @Nullable String ifaceStrict,
            @Nullable String ifaceHint, @Nullable Logger logger) throws UnknownHostException, IOException {
        InetAddress[] inets = InetAddress.getAllByName(hostnameOrIp);
        boolean online = false;
        NetworkInterface iface = null;
        if (ifaceStrict != null) {
            iface = getIface(ifaceStrict, logger);
        }
        NetworkInterface ifaceLastKnown = null;
        if (ifaceHint != null && !ifaceHint.equalsIgnoreCase(String.valueOf(ifaceStrict))) {
            ifaceLastKnown = getIface(ifaceHint, logger);
        }

        for (InetAddress inet : inets) {
            if (logger != null) {
                logger.debug("Java ping: {}/{}", hostnameOrIp, inet.getHostAddress());
            }

            if (iface != null) {
                if (logger != null) {
                    logger.debug("Ping via configured iface: {}", iface.getName());
                }
                if (inet.isReachable(iface, TTL, TIMEOUT_MILLIS)) {
                    online = true;
                }
            }
            if (!online && ifaceLastKnown != null) {
                if (logger != null) {
                    logger.debug("Ping via last known iface: {}", ifaceLastKnown.getName());
                }
                if (inet.isReachable(ifaceLastKnown, TTL, TIMEOUT_MILLIS)) {
                    online = true;
                }
            }
            if (!online) {
                if (logger != null) {
                    logger.debug("Ping via: kernel selected iface");
                }
                if (inet.isReachable(TIMEOUT_MILLIS)) {
                    online = true;
                }
            }

            if (online) {
                if (logger != null) {
                    logger.debug("{}/{} seems to be online", hostnameOrIp, inet.getHostAddress());
                }
                return true;
            } else {
                if (logger != null) {
                    logger.debug("{}/{} seems to be offline", hostnameOrIp, inet.getHostAddress());
                }
            }
        }
        return false;
    }
}
