/**
 * Copyright (c) 2010-2018 by the respective copyright holders.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * @author Ganesh Ingle <ganesh.ingle@asvilabs.com>
 */

package org.openhab.binding.wakeonlan;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.smarthome.core.thing.ThingTypeUID;

/**
 * The {@link WakeOnLanBindingConstants} class defines common constants, which are
 * used across the whole binding.
 *
 * @author Ganesh Ingle - initial contribution
 */
public class WakeOnLanBindingConstants {

    public static final int DFLT_DISCOVERY_RESULTS_LIMIT = 20;
    public static final int DFLT_DISCOVERY_TIMEOUT_SEC = 120;
    public static final int DFLT_DISCOVERY_RESULT_TTL_SEC = 900;

    public static final String DISCOVERY_CONFIG_RESULTS_LIMIT = "resultsLimit";
    public static final String DISCOVERY_CONFIG_RESULTS_TTL_SEC = "resultsTTLSec";
    public static final String DISCOVERY_CONFIG_DISCOVERY_TIMEOUT_SEC = "discoveryTimeoutSec";

    public static final String THING_CONFIG_TARGET_MAC = "targetMAC";
    public static final String THING_PROP_REPRESENTATION = "targetId";
    public static final String THING_CONFIG_TARGET_IP = "targetIP";
    public static final String THING_CONFIG_PERIODIC_PING = "periodicPing";
    public static final String THING_CONFIG_SEND_ON_IF = "sendOnInterface";
    public static final String THING_PROP_IF_HINT = "interfaceHint";
    public static final String THING_CONFIG_SEND_ON_ALL_IF = "sendOnAllInterfaces";
    public static final String THING_CONFIG_PING_HOST = "pingHostnameOrIp";
    public static final String THING_CONFIG_SET_SO_BROAD = "setSoBroadcast";

    public static final String BINDING_ID = "wakeonlan";
    public static final String BINDING_LOGGER_NAME = "org.openhab.binding.wakeonlan";

    // List of all Thing Type UIDs
    public static final ThingTypeUID THING_TYPE_WOLDEVICE = new ThingTypeUID(BINDING_ID, "wol-device");

    // List of all Channel id's
    public static final String CHANNEL_WAKEUP = "wakeup";
    public static final String CHANNEL_SHUTDOWN = "shutdown";
    public static final String CHANNEL_STATUS = "status";
    public static final String CHANNEL_POWER = "power";

    public static final Set<ThingTypeUID> SUPPORTED_THING_TYPES_UIDS = new HashSet<ThingTypeUID>(
            Arrays.asList(THING_TYPE_WOLDEVICE));

    public static final String DFLT_BROADCAST_ADDRESS = "255.255.255.255";
    public static final Integer DFLT_UDP_WOL_PORT = 9;
    public static final int MAX_HIGHER_FREQ_PING_COUNT = 16;
    public static final long HIGHER_FREQ_PING_INTERVAL_MILLIS = 15000;

    // List of standard statuses
    public static final String STATUS_PACKET_SENT = "Packet Sent";
    public static final String STATUS_SHUTDOWN_COMMANDS_SENT = "Shutdown Commands Sent";
    public static final String STATUS_READY = "Ready";
    public static final String STATUS_UPDATING = "Updating";
    public static final String STATUS_HOST_ONLINE = "Online";
    public static final String STATUS_HOST_OFFLINE = "Offline";
    public static final String STATUS_SHUTDOWN_COMMANDS_NOT_CONFIGURED = "Shutdown Command Not Configured";
}
